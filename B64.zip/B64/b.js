function check(){
        let city=document.getElementById('city');
        let district=document.getElementById('district');

        if(city.value==="hyd"){
        
          window.location.href="a1.html";
        }
else{
     window.location.href="a2.html";
}
    }